package com.infy.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.Entity.Account;

public interface AccountRepo extends JpaRepository<Account,String>{

}
