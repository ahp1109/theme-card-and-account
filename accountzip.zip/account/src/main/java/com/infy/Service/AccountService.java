package com.infy.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.DTO.AccountDTO;
import com.infy.Entity.Account;
import com.infy.Repository.AccountRepo;

@Service
public class AccountService {
	
	@Autowired
	AccountRepo accountRepo;
	
	public Account convertDTOtoEntity(AccountDTO aDto) {
		Account account = new Account();
		
		account.setEmailid(aDto.getEmailid());
		account.setAccounttype(aDto.getAccounttype());
		account.setName(aDto.getName());
		account.setPassword(aDto.getPassword());
		
		return account;
		
	}
	
	public String add(Account acc) {
		
		accountRepo.saveAndFlush(acc);
		return "Account created";
	}
	
	public Account getEntityObject(String emailid) {
		
		return(accountRepo.findById(emailid).get());	
		}

}
