package com.infy.DTO;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class AccountDTO {	
	
	@NotNull
	@Email(message = "{email.val}")
	String emailid;
	@Pattern(regexp = "[A-Z a-z.]{5,20}",message = "{name.val}")
	@NotNull
	String name;
	@NotNull
	@Pattern(regexp = "^(?=.{8,}$)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\\W).*$",message = "{password.val}")
	String password;
	
	@Pattern(regexp = "^(?:Seller|Buyer)$",message = "{accounttype.val}")
	@NotNull
	String accounttype;
	
	
	public AccountDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public AccountDTO(String emailid, String name, String password,String accounttype) {
		super();
		this.emailid = emailid;
		this.name = name;
		this.password = password;
		this.accounttype =accounttype;
	}


	public String getEmailid() {
		return emailid;
	}


	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	


	public String getAccounttype() {
		return accounttype;
	}


	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}


	@Override
	public String toString() {
		return "Account [emailid=" + emailid + ", name=" + name + ", password=" + password + "]";
	}

}
