package com.infy.Controller;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.DTO.AccountDTO;
import com.infy.Entity.Account;
import com.infy.Service.AccountService;
import com.infy.exceptions.InvalidDetailsException;

@RestController
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	AccountService accountService;
	Account acc;
	
	@PostMapping(consumes="application/json")
	public String registerAccount(@Valid @RequestBody AccountDTO aDto) throws InvalidDetailsException {
		 
		return(accountService.add(accountService.convertDTOtoEntity(aDto)));
		
	}
	
	@PutMapping("updatepassword/{emailid}/{password}")
	public String updatePassword(@PathVariable("emailid")@Email(message = "{email.val}")
								String emailid,@PathVariable("password")
	                            @Pattern(regexp = "^(?=.{8,}$)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\\W).*$",message = "{password.val}")
	                            String password) throws InvalidDetailsException {
		
		acc = accountService.getEntityObject(emailid);
		acc.setPassword(password);
		accountService.add(acc);
		
		return "Password updated successfully";
	}
	
	@PutMapping("updatename/{emailid}/{name}")
	public String updateName(@PathVariable("emailid")@Email(message = "{email.val}")
								String emailid,@PathVariable("name")
								@Pattern(regexp = "[A-Z a-z.]{5,20}",message = "{name.val}")
	                            String name) throws InvalidDetailsException {
		
		acc = accountService.getEntityObject(emailid);
		acc.setName(name);
		accountService.add(acc);
		
		return "Name updated successfully";
	}

}
