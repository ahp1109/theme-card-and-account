package com.infy.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Account {
	
	@Id
	String emailid;
	String name;
	String password;
	String accounttype;
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Account(String emailid, String name, String password,String accounttype) {
		super();
		this.emailid = emailid;
		this.name = name;
		this.password = password;
		this.accounttype=accounttype;
	}


	public String getEmailid() {
		return emailid;
	}


	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	


	public String getAccounttype() {
		return accounttype;
	}


	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}


	@Override
	public String toString() {
		return "Account [emailid=" + emailid + ", name=" + name + ", password=" + password + "]";
	}
	
	
	
	
	
	

}
