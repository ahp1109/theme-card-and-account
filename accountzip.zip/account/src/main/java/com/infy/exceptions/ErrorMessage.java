package com.infy.exceptions;

public class ErrorMessage {
   int ecode;
   String emsg;
   public int getEcode() {
	return ecode;
}
public void setEcode(int ecode) {
	this.ecode = ecode;
}
public String getEmsg() {
	return emsg;
}
public void setEmsg(String emsg) {
	this.emsg = emsg;
}

}
