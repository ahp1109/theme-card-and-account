package com.infy.exceptions;



import java.time.format.DateTimeParseException;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;



@RestControllerAdvice
public class ExceptionHandlerGlobal {
	

	@ExceptionHandler(DateTimeParseException.class)
	public ResponseEntity<Object> callme1(DateTimeParseException e)
	{
		ErrorMessage error = new ErrorMessage();
		error.setEcode(HttpStatus.BAD_GATEWAY.value());
		error.setEmsg("Enter Date in yyyy-mm-dd format");
		return new ResponseEntity<>(error, HttpStatus.OK);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> callme1(Exception e)
	{
		ErrorMessage error = new ErrorMessage();
		error.setEcode(HttpStatus.BAD_GATEWAY.value());
		error.setEmsg(e.getMessage());
		return new ResponseEntity<>(error, HttpStatus.OK);
	}
	
	
	@ExceptionHandler(InvalidDetailsException.class)
	public ResponseEntity<Object> callme2(InvalidDetailsException e)
	{
		ErrorMessage error = new ErrorMessage();
		error.setEcode(HttpStatus.BAD_GATEWAY.value());
		error.setEmsg(e.getMessage());
		return new ResponseEntity<>(error, HttpStatus.OK);
	}
	
	
}