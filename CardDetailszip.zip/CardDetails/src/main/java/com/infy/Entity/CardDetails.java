package com.infy.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CardDetails {
	
	@Id
	String cardnumber;
	int cvv;
	String cardtype;
	String expirydate;
	String name;
	String emailid;
	
	
	
	public CardDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CardDetails(String cardnumber, int cvv, String cardtype, String expirydate, String name, String emailid) {
		super();
		this.cardnumber = cardnumber;
		this.cvv = cvv;
		this.cardtype = cardtype;
		this.expirydate = expirydate;
		this.name = name;
		this.emailid = emailid;
	}
	public String getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public String getCardtype() {
		return cardtype;
	}
	public void setCardtype(String cardtype) {
		this.cardtype = cardtype;
	}
	public String getExpirydate() {
		return expirydate;
	}
	public void setExpirydate(String expirydate) {
		this.expirydate = expirydate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	@Override
	public String toString() {
		return "CardDetails [cardnumber=" + cardnumber + ", cvv=" + cvv + ", cardtype=" + cardtype + ", expirydate="
				+ expirydate + ", name=" + name + ", emailid=" + emailid + "]";
	}
	
	
	
	
	
	

}
