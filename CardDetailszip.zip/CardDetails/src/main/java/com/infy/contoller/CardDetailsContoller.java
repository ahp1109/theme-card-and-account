package com.infy.contoller;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.DTO.CardDetailsDTO;
import com.infy.exceptions.InvalidDetailsException;
import com.infy.service.CardDetailsService;

@RestController
@RequestMapping("/carddetails")
public class CardDetailsContoller {
	
	@Autowired
	CardDetailsService cardDetailsService;
	
	@PostMapping(consumes="application/json")
	public String registerCardDetails(@Valid @RequestBody CardDetailsDTO cDto)throws InvalidDetailsException {
		
		boolean cardvalidity = cardDetailsService.verifyLuhns(cDto.getCardnumber());
		int value = cardDetailsService.checkCardValidity(cDto.getExpirydate());
		if(cardvalidity && value==1){
			cardDetailsService.add(cardDetailsService.convertDTOtoEntity(cDto));
			return "Card added";
		}
		else if(value==0) {
			return "Card Expired";
		}
		else {
			return "Card number invalid";
		}		
	}
	
	@DeleteMapping("{cardnumber}")
	public String removeCard(@PathVariable("cardnumber") 
	                  @Pattern(regexp = "[0-9]{16}",message = "{card.val}")
	                  String cardnumber)throws InvalidDetailsException {
		
		cardDetailsService.deleteCard(cardnumber);
		return "Card removed";
		
	}
	
	@GetMapping("{emailid}")
	public Object viewCards(@PathVariable("emailid")@Email(message = "{email.val}")
						 String emailid) throws InvalidDetailsException{
		
		if(cardDetailsService.getAllCards(emailid).isEmpty()) {
			return "No Card Found";
		}
		else return( cardDetailsService.getAllCards(emailid));
		
	}
	
	

}
