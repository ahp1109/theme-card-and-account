package com.infy.service;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.DTO.CardDetailsDTO;
import com.infy.Entity.CardDetails;
import com.infy.Repository.CardDetailsRepo;

@Service
public class CardDetailsService {
	@Autowired
	CardDetailsRepo cardDetailsRepo;
	

	public void add(CardDetails card) {
		// TODO Auto-generated method stub
		cardDetailsRepo.saveAndFlush(card);
	}
	
	public boolean verifyLuhns(String cardnumber) {
		int nDigits = cardnumber.length();
		 
	    int nSum = 0;
	    boolean isSecond = false;
	    for (int i = nDigits - 1; i >= 0; i--)
	    {	 
	        int d = cardnumber.charAt(i) - '0';
	 
	        if (isSecond == true)
	            d = d * 2;
	        
	        nSum += d / 10;
	        nSum += d % 10;
	 
	        isSecond = !isSecond;
	    }
	    return (nSum % 10 == 0); 		
	}
	
	public CardDetails convertDTOtoEntity(CardDetailsDTO cDTO) {
		CardDetails cardDetails = new CardDetails();
		
		cardDetails.setCardnumber(cDTO.getCardnumber());
		cardDetails.setCardtype(cDTO.getCardtype());
		cardDetails.setCvv(cDTO.getCvv());
		cardDetails.setExpirydate(cDTO.getExpirydate());
		cardDetails.setEmailid(cDTO.getEmailid());
		cardDetails.setName(cDTO.getName());
		
		return cardDetails;
	}
	
	public int checkCardValidity(String exp) {
		LocalDate dateObj = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yy");
        String date = dateObj.format(formatter);
        int expyear = Integer.parseInt(exp.substring(3,5));
        int curyear = Integer.parseInt(date.substring(3,5));
        int expmonth = Integer.parseInt(exp.substring(0,2));
        int curmonth = Integer.parseInt(date.substring(0,2));
        if(expyear<curyear) return 0;          
        else if(expyear>curyear) return 1;
        else if(expmonth>=curmonth) return 1;
        else return 0;   	
	}
	
	public void deleteCard(String cardnumber) {
		
		cardDetailsRepo.deleteById(cardnumber);
	}
	
	public List<CardDetails> getAllCards(String emailid) {
	  return(cardDetailsRepo.findByEmailid(emailid));
	}
}
