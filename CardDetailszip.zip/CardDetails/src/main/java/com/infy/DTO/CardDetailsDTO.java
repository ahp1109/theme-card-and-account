package com.infy.DTO;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


public class CardDetailsDTO {
	@Pattern(regexp = "[0-9]{16}",message = "{card.val}")
	String cardnumber;

	@Min(value = 100,message = "{cvv.val}")
	@Max(value = 999,message = "{cvv.val}")
	int cvv;
	@NotNull(message = "{card.val}")
	String cardtype;
	@Pattern(regexp = "^(0[1-9]|1[012])/[0-9]{2}$",message = "{expirydate.val}")
	String expirydate;
	@Pattern(regexp = "[A-Z a-z.]{5,20}",message = "{name.val}")
	String name;
	@Email(message = "{email.val}")
	@NotNull
	String emailid;
	
	
	
	public CardDetailsDTO() {
		// TODO Auto-generated constructor stub
	
		super();
		// TODO Auto-generated constructor stub
	}
	public CardDetailsDTO(String cardnumber, int cvv, String cardtype, String expirydate, String name, String emailid) {
		super();
		this.cardnumber = cardnumber;
		this.cvv = cvv;
		this.cardtype = cardtype;
		this.expirydate = expirydate;
		this.name = name;
		this.emailid = emailid;
	}
	public String getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public String getCardtype() {
		return cardtype;
	}
	public void setCardtype(String cardtype) {
		this.cardtype = cardtype;
	}
	public String getExpirydate() {
		return expirydate;
	}
	public void setExpirydate(String expirydate) {
		this.expirydate = expirydate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	@Override
	public String toString() {
		return "CardDetails [cardnumber=" + cardnumber + ", cvv=" + cvv + ", cardtype=" + cardtype + ", expirydate="
				+ expirydate + ", name=" + name + ", emailid=" + emailid + "]";
	}

}
