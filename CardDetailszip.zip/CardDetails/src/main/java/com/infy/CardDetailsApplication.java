package com.infy;

import org.springframework.context.ApplicationContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.infy.Entity.CardDetails;
import com.infy.service.CardDetailsService;

@SpringBootApplication
public class CardDetailsApplication {

	public static void main(String[] args) {
		ApplicationContext ac = SpringApplication.run(CardDetailsApplication.class, args);
		CardDetailsService c = ac.getBean(CardDetailsService.class);

//		CardDetails card1 = new CardDetails("1234567891234567", 877,"Debit", "12/25", "Akash", "abc@gmail.com");
//		CardDetails card2 = new CardDetails("1111111111111111", 111,"Credit", "08/26", "Saurav", "sss@gmail.com");
//		
//		c.add(card1);
//		c.add(card2);
	}

}
