package com.infy.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.Entity.CardDetails;

import java.util.List;

public interface CardDetailsRepo extends JpaRepository<CardDetails, String>{
	
	
	List<CardDetails> findByEmailid(String emailid);

}
